exports.PORT = 3000;
exports.DB_QUERYSTRING = 'mongodb://localhost:27017/crypto';
exports.SALT_ROUNDS = 9;
exports.SECRET = 'a237d47f5fasdl0d2f64fae7e1f313e247d';